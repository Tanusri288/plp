package com.capg.dao;

import java.sql.SQLException;

import com.capg.bean.BankBean;
import com.capg.bean.BankTransaction;

public interface bankDaoImpl {



	public void InsertData(long actNum, BankBean bean) throws ClassNotFoundException, SQLException;
	
	public void updateData(BankBean bean) throws ClassNotFoundException, SQLException;

	public boolean checkAccount(long actNum) throws ClassNotFoundException, SQLException;

	public BankBean getAccountDetails(long actNum) throws ClassNotFoundException, SQLException;

	public void setTransactions(BankTransaction trans) throws ClassNotFoundException, SQLException;

	public BankTransaction getTransactions(long actNum) throws ClassNotFoundException, SQLException;

}
