package com.capg.ui;

import java.sql.SQLException;
import java.util.Scanner;

import com.capg.bean.BankTransaction;
import com.capg.exceptions.*;
import com.capg.service.bankService;
import com.capg.service.bankServiceImpl;

public class bankMain {
	static Scanner scanner = new Scanner(System.in);
	static BankTransaction trans = new BankTransaction();
	static BankTransaction trans1 = new BankTransaction();

	public static int menu() {
		
		
		// displaying menu
		
		System.out.println("\n\n<<<<<<<<<<<<<<<<<<<<.............Welcome to XYZ Bank Application.............>>>>>>>>>>>>>>>>>>");
				
				System.out.println("\n\nChoose your option: \n 1. Create Account\n 2. Show Balance\n 3. Deposit amount\n 4. WithDraw amount\n 5. Fund Transfer\n 6. Print Transaction\n 7. Exit");
				
				System.out.println("Enter Your choice : ");
				int choice = scanner.nextInt();

				String str = Integer.toString(choice);
				String pattern = ("[0-7]{1}");
				while (!str.matches(pattern)) {
					System.out.println("Invalid Choice");
					System.out.println("Enter Choice");
					choice = scanner.nextInt();
				}
				return choice;
			}

	public static void main(String[] args) throws accountNotFoundException, ClassNotFoundException, SQLException {

		// variables used

		long senderAccountNo, receiverAccountNo;
		int withdraw_amount, deposit_amount = 0, transfer_amount = 0;
		int trans_id_1=0, trans_id_2=0;
		int pin;
		int amount = 0;
		int balance = 0;
		boolean res = false;
		String cont = "yes";

		bankServiceImpl service = new bankService();

		while (cont.equalsIgnoreCase("yes")) {
			switch (menu()) {

			// Creating an account

			case 1:

				System.out.println("Enter the name");
				String name = scanner.nextLine();
				name += scanner.nextLine();

				String regexUserName = "[A-Za-z\\s]+$";
				while (!name.matches(regexUserName)) {

					System.out.println("Invalid Format Name");
					System.out.println("Enter a valid name");
					name = scanner.next();
				}

				System.out.println("Enter the address ");
				String add = scanner.next();
				add += scanner.nextLine();

				while (!add.matches(regexUserName)) {
					System.out.println("Invalid Address Format");
					System.out.println("Enter a valid address ");
					add = scanner.nextLine();

				}

				System.out.println("Enter the mobile number");
				String phone = scanner.next();
				String phone_format = ("[4-9][0-9]{9}");

				while (!phone.matches(phone_format)) {
					while (phone.length() < 10 || phone.length() > 10) {

						System.out.println("Mobile number should be of 10 digits");
						System.out.println("Enter mobile number");
						phone = scanner.next();
					}
					System.out.println("Mobile number should starts from 4");
					System.out.println("Enter a valid mobile number");
					phone = scanner.next();
				}

				senderAccountNo = Long.parseLong(phone) - 10000;

				System.out.println("Enter Pin");
				pin = scanner.nextInt();

				while (String.valueOf(pin).length() < 4 || String.valueOf(pin).length() > 4) {

					System.out.println("Pin number should be 0f 4 digits");
					System.out.println("Enter a valid Pin");
					pin = scanner.nextInt();
				}

				System.out.println("Enter the Balance");
				int bal = scanner.nextInt();

				while (bal < 1000) {
					System.out.println("Minimum Balance should be 1000");
					System.out.println("Enter the Balance");
					bal = scanner.nextInt();

				}
				try {
					res = service.createAccount(name, add, senderAccountNo, phone, pin, bal);
				} catch (accountAlreadyExistsException e) {

					System.out.println(e);
					break;
				}

				if (res == true) {
					System.out.println("Your account has been created successfully....!!!");
					System.out.println("Your account number is: " + senderAccountNo);

//					int trans_id = ((int) Math.random() * 1000 + 1000);
					trans.setAccNo(senderAccountNo);
					trans.setType("Create");
					trans.setAmount(bal);
					trans.setTransaction_id(trans_id_1);

					service.setTransactions(trans);

				} else {

					System.out.println("Cannot be able to create the account");
				}

				break;

			//displaying balance
				
			case 2:

				System.out.println("Enter the account number");
				senderAccountNo = scanner.nextLong();

				try {
					balance = service.showBalance(senderAccountNo);
				} catch (accountNotFoundException e) {
					System.out.println(e);
					break;
				}

				System.out.println("Your account balance is :" + balance);

				break;

			// depositing amount to account

			case 3:

				System.out.println("Enter the account number");
				senderAccountNo = scanner.nextLong();

				System.out.println("Enter the amount to be deposited");
				deposit_amount = scanner.nextInt();

				try {
					amount = service.deposit(senderAccountNo, deposit_amount);

					balance = service.showBalance(senderAccountNo);
				}

				catch (accountNotFoundException e) {

					System.out.println(e);
					break;
				}

				System.out.println("Amount has been deposited : " + deposit_amount);
				System.out.println("Your updated balance is : " + balance);

//				int trans_id = ((int) Math.random() * 1000 + 1000);
				trans.setAccNo(senderAccountNo);
				trans.setType("Deposit");
				trans.setAmount(deposit_amount);
				trans.setTransaction_id(trans_id_1);
				service.setTransactions(trans);

				break;

			// withdrawing amount from account

			case 4:

				System.out.println("Enter the account number");
				senderAccountNo = scanner.nextLong();

				System.out.println("Enter the amount to withdraw");
				withdraw_amount = scanner.nextInt();

				try {
					amount = service.withdraw(senderAccountNo, withdraw_amount);
					res = service.validateBalance(senderAccountNo, withdraw_amount);
					balance = service.showBalance(senderAccountNo);

				} catch (accountNotFoundException e) {

					System.out.println(e);
					break;

				} catch (lessBalanceException e) {

					System.out.println(e);
					break;
				}

				System.out.println("Amount has been Withdrawn : " + withdraw_amount);
				System.out.println("Your updated balance is: " + balance);

//				int trans_id1 = ((int) Math.random() * 1000 + 1000);
				trans.setAccNo(senderAccountNo);
				trans.setType("Withdraw");
				trans.setAmount(withdraw_amount);
				trans.setTransaction_id(trans_id_1);
				service.setTransactions(trans);

				break;

			//amount transfering from one account to another account

			case 5:

				int senders_balance = 0;
				int recievers_balance = 0;

				System.out.println("Enter your account number");
				senderAccountNo = scanner.nextLong();

				System.out.println("Enter the receivers account number");
				receiverAccountNo = scanner.nextLong();
				
				System.out.println("Enter pin");
				pin = scanner.nextInt();

				System.out.println("Enter the amount to transfer");
				transfer_amount = scanner.nextInt();

				try {
					res = service.validateBalance(senderAccountNo, transfer_amount);
					res = service.transferfund(senderAccountNo, receiverAccountNo, transfer_amount);

					senders_balance = service.showBalance(senderAccountNo);
					recievers_balance = service.showBalance(receiverAccountNo);

				} catch (accountNotFoundException e) {

					System.out.println(e);
					break;
				} catch (lessBalanceException e) {
					System.out.println(e);
					break;
				}

				System.out.println("Amount has been transferred Successfully..!!!");
				System.out.println("The updated balance for account " + senderAccountNo + " : " + senders_balance);
				System.out.println("updated balance for account " + receiverAccountNo + " : " + recievers_balance);

//				int trans_id_1 = ((int) Math.random() * 1000 + 1000);
				trans.setAccNo(senderAccountNo);
				trans.setType("Transfer");
				trans.setAmount(transfer_amount);
				trans.setTransaction_id(trans_id_1);
				service.setTransactions(trans);

//				int trans_id_2 = ((int) Math.random() * 1000 + 1000);
				trans1.setAccNo(receiverAccountNo);
				trans1.setType("Receive");
				trans1.setAmount(transfer_amount);
				trans1.setTransaction_id(trans_id_2);
				service.setTransactions(trans1);

				break;

			// displaying the transactions of particular account
				
			case 6:

				System.out.println("Enter the account number");
				senderAccountNo = scanner.nextLong();
				trans = service.getTransactions(senderAccountNo);
				if (trans == null) {
					throw new accountNotFoundException();
				} else {
					System.out.println("***************	 Your Transaction Details	 ***************");
					System.out.println("Transaction type : " + trans.getType());
					System.out.println("Transaction Id : " + trans.getTransaction_id());
					System.out.println("Transaction Account : " + trans.getAccNo());
					System.out.println("Transaction Amount : " + trans.getAmount());
				}
                break;
                
				// exit
                
                
			case 7:
				System.out.println("<<<<<<<<<<<<<<<<<<<<.............Thank you for banking with us.............>>>>>>>>>>>>>>>>>>");
			System.exit(0);
				break;
		
				//when user enters invalid choice
				
			default:
				System.out.println("Please enter a valid choice..!!!");
				menu();

			}
		}

	}
	
}
