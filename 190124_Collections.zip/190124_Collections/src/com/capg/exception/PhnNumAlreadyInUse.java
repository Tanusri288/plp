
package com.capg.exception;

public class PhnNumAlreadyInUse extends Exception {

	public PhnNumAlreadyInUse() {

	}

	@Override
	public String toString() {
		return "this phone number is already linked with other accounts";
	}

}
