package com.capg.exception;

public class InsufficientBalanceException extends Exception {

	public InsufficientBalanceException() {

	}

	@Override
	public String toString() {
		return "Low Balance \nCannot Operation";
	}

}
