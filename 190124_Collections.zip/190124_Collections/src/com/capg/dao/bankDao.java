package com.capg.dao;
import java.util.HashMap;

import com.capg.bean.bankBean;
import com.capg.exception.accountNotFoundException;



public class bankDao implements BankDaoImpl {


		HashMap hMap;

		public bankDao() {

			hMap = new HashMap();
		}

		// bean class object

		bankBean bean = new bankBean();



		public bankBean checkAccount(long accNo) throws accountNotFoundException {

			if (hMap.containsKey(accNo)) {

				bean = (bankBean) hMap.get(accNo);
				return bean;

			} else

				throw new accountNotFoundException();
		}

		// to put the data into the map

		public void setData(long accNo, bankBean bean) {

			hMap.put(accNo, bean);
		}

	}


