package com.capg.dao;

import com.capg.bean.bankBean;
import com.capg.exception.accountNotFoundException;

public interface BankDaoImpl {

	public bankBean checkAccount(long accNo) throws accountNotFoundException;

	public void setData(long accNo, bankBean bean);

}
