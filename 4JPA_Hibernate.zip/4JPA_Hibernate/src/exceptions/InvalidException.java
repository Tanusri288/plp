package exceptions;

public class InvalidException extends Exception {
//	public InvalidException(String msg) {
//		System.out.println(msg);
//}
	public InvalidException() {

	}

	@Override
	public String toString() {
		return "Account not found";
	}
	
}