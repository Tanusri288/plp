package exceptions;

public class Exp extends Exception{
	public Exp(String msg) {
	System.out.println(msg);
}
}
